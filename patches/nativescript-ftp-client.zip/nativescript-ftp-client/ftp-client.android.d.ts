import "globals";
export declare class FtpClient {
    private worker;
    private promises;
    private instance;
    postMessage(obj: any): void;
    connect(url: string, port: number): Promise<any>;
    login(username: string, password: string): Promise<any>;
    changeDirectory(path: string): Promise<any>;
    upload(path: string): Promise<any>;
    disconnect(): Promise<any>;
    list(): Promise<any>;
    download(file: any, localFile: any): Promise<any>;
    rename(oldFile: any, newFile: any): Promise<any>;
    deleteFile(file: any): Promise<any>;
    deleteDirectory(directory: any): Promise<any>;
    createDirectory(directory: any): Promise<any>;
	sendCustomCommand(comando: any): Promise<any>;
}
