// typings/custom.d.ts
declare module "nativescript-worker-loader!*" {
  const content: any;
  export = content;
}