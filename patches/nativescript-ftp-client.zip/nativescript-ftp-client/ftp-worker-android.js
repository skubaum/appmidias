"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
require("globals");
var FtpWorker = (function () {
    function FtpWorker() {
        var me = this;
        try {
            me.client = new it.sauronsoftware.ftp4j.FTPClient();
        }
        catch (error) {
            console.log(error);
        }
        global.onmessage = function (msg) {
            var data = msg.data;
            var method = data.method;
            try {
                var response = me[method](data);
                global.postMessage({ uuid: data.uuid, error: false, data: response });
            }
            catch (error) {
                global.postMessage({ uuid: data.uuid, error: true, data: error.message });
            }
        };
    }
    FtpWorker.prototype.connect = function (data) {
        var me = this;
        if (data.port != undefined)
            return me.client.connect(data.url, data.port);
        else
            return me.client.connect(data.url);
    };
    FtpWorker.prototype.login = function (data) {
        var me = this;
        return me.client.login(data.username, data.password);
    };
    FtpWorker.prototype.changeDirectory = function (data) {
        var me = this;
        return me.client.changeDirectory(data.path);
    };
    FtpWorker.prototype.upload = function (data) {
        var me = this;
        return me.client.upload(new java.io.File(data.path));
    };
    FtpWorker.prototype.disconnect = function () {
        var me = this;
        return me.client.disconnect(true);
    };
    FtpWorker.prototype.list = function () {
        var me = this;
        var files = me.client.list();
        var fin = [];
        for (var _i = 0, files_1 = files; _i < files_1.length; _i++) {
            var file = files_1[_i];
			//console.log("ftp-worker-android.js/list: ", file);
            fin.push({
                type: (file.getType() == it.sauronsoftware.ftp4j.FTPFile.TYPE_DIRECTORY) ? 'directory' : 'file',
                name: file.getName(),
				mdate: file.getModifiedDate().toString(),
				file: file.toString(),
				size: file.getSize()
            });
        }
        return fin;
    };
    FtpWorker.prototype.download = function (data) {
        var me = this;
        var fileOut = new java.io.File(data.localFile);
        return me.client.download(data.file, fileOut);
    };
    FtpWorker.prototype.rename = function (data) {
        var me = this;
        return me.client.rename(data.oldFile, data.newFile);
    };
    FtpWorker.prototype.deleteFile = function (data) {
        var me = this;
        return me.client.deleteFile(data.file);
    };
    FtpWorker.prototype.deleteDirectory = function (data) {
        var me = this;
        return me.client.deleteDirectory(data.directory);
    };
    FtpWorker.prototype.createDirectory = function (data) {
        var me = this;
        return me.client.createDirectory(data.directory);
    };
	FtpWorker.prototype.sendCustomCommand = function (data) {
        var me = this;
		//console.log("sendCustomCommand: ", data.comando);
        return me.client.sendCustomCommand(data.comando);
    };
    return FtpWorker;
}());
exports.FtpWorker = FtpWorker;
new FtpWorker();
//# sourceMappingURL=ftp-worker-android.js.map