import "globals";
export declare class FtpWorker {
    private client;
    constructor();
    connect(data: any): any;
    login(data: any): any;
    changeDirectory(data: any): any;
    upload(data: any): any;
    disconnect(): any;
    list(): any;
    download(data: any): any;
    rename(data: any): any;
    deleteFile(data: any): any;
    deleteDirectory(data: any): any;
    createDirectory(data: any): any;
}
