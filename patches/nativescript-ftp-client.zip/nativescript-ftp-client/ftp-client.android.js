"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
require("globals");
var FtpClient = (function () {
    function FtpClient() {
        this.promises = {};
        this.instance = 0;
    }
    FtpClient.prototype.postMessage = function (obj) {
        var me = this;
        me.instance++;
        var id = me.instance;
        obj.uuid = id;
        me.promises[id] = obj;
        me.worker.postMessage(obj);
    };
    FtpClient.prototype.connect = function (url, port) {
        var me = this;
        return new Promise(function (resolve, reject) {
            try {
                me.worker;
                if (global.TNS_WEBPACK) {
                    var FtpWorker = require("nativescript-worker-loader!./ftp-worker-android.js");
                    me.worker = new FtpWorker();
                }
                else {
                    me.worker = new Worker('./ftp-worker-android.js');
                }
                me.worker.onmessage = function (msg) {
                    if (msg.data.uuid) {
                        var obj = me.promises[msg.data.uuid];
                        if (obj == undefined) {
                            console.log('Message does not contain uuid', msg.data);
                            return;
                        }
                        if (msg.data.error == false)
                            obj.resolve(msg.data.data);
                        else
                            obj.reject(msg.data.data);
                    }
                    else {
                        console.log('Message does not contain uuid', msg.data);
                    }
                };
                me.postMessage({
                    method: 'connect',
                    url: url,
                    port: port,
                    resolve: resolve,
                    reject: reject
                });
            }
            catch (error) {
                reject(error);
            }
        });
    };
    FtpClient.prototype.login = function (username, password) {
        var me = this;
        return new Promise(function (resolve, reject) {
            try {
                me.postMessage({
                    method: 'login',
                    username: username,
                    password: password,
                    resolve: resolve,
                    reject: reject
                });
            }
            catch (error) {
                reject(error);
            }
        });
    };
    FtpClient.prototype.changeDirectory = function (path) {
        var me = this;
        return new Promise(function (resolve, reject) {
            try {
                me.postMessage({
                    method: 'changeDirectory',
                    path: path,
                    resolve: resolve,
                    reject: reject
                });
            }
            catch (error) {
                reject(error);
            }
        });
    };
    FtpClient.prototype.upload = function (path) {
        var me = this;
        return new Promise(function (resolve, reject) {
            try {
                me.postMessage({
                    method: 'upload',
                    path: path,
                    resolve: resolve,
                    reject: reject
                });
            }
            catch (error) {
                reject(error);
            }
        });
    };
    FtpClient.prototype.disconnect = function () {
        var me = this;
        return new Promise(function (resolve, reject) {
            try {
                me.postMessage({
                    method: 'disconnect',
                    resolve: resolve,
                    reject: reject
                });
                me.worker.terminate();
            }
            catch (error) {
                reject(error);
            }
        });
    };
    FtpClient.prototype.list = function () {
        var me = this;
        return new Promise(function (resolve, reject) {
            try {
                me.postMessage({
                    method: 'list',
                    resolve: resolve,
                    reject: reject
                });
            }
            catch (error) {
                reject(error);
            }
        });
    };
    FtpClient.prototype.download = function (file, localFile) {
        var me = this;
        return new Promise(function (resolve, reject) {
            try {
                me.postMessage({
                    method: 'download',
                    file: file,
                    localFile: localFile,
                    resolve: resolve,
                    reject: reject
                });
            }
            catch (error) {
                reject(error);
            }
        });
    };
    FtpClient.prototype.rename = function (oldFile, newFile) {
        var me = this;
        return new Promise(function (resolve, reject) {
            try {
                me.postMessage({
                    method: 'rename',
                    oldFile: oldFile,
                    newFile: newFile,
                    resolve: resolve,
                    reject: reject
                });
            }
            catch (error) {
                reject(error);
            }
        });
    };
    FtpClient.prototype.deleteFile = function (file) {
        var me = this;
        return new Promise(function (resolve, reject) {
            try {
                me.postMessage({
                    method: 'deleteFile',
                    file: file,
                    resolve: resolve,
                    reject: reject
                });
            }
            catch (error) {
                reject(error);
            }
        });
    };
    FtpClient.prototype.deleteDirectory = function (directory) {
        var me = this;
        return new Promise(function (resolve, reject) {
            try {
                me.postMessage({
                    method: 'deleteDirectory',
                    directory: directory,
                    resolve: resolve,
                    reject: reject
                });
            }
            catch (error) {
                reject(error);
            }
        });
    };
    FtpClient.prototype.createDirectory = function (directory) {
        var me = this;
        return new Promise(function (resolve, reject) {
            try {
                me.postMessage({
                    method: 'createDirectory',
                    directory: directory,
                    resolve: resolve,
                    reject: reject
                });
            }
            catch (error) {
                reject(error);
            }
        });
    };
	FtpClient.prototype.sendCustomCommand = function (comando) {
        var me = this;
        return new Promise(function (resolve, reject) {
            try {
                me.postMessage({
                    method: 'sendCustomCommand',
                    comando: comando,
                    resolve: resolve,
                    reject: reject
                });
            }
            catch (error) {
                reject(error);
            }
        });
    };
    return FtpClient;
}());
exports.FtpClient = FtpClient;
//# sourceMappingURL=ftp-client.android.js.map