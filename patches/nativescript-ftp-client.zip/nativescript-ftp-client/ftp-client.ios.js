"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var FtpClient = (function () {
    function FtpClient() {
    }
    return FtpClient;
}());
exports.FtpClient = FtpClient;
//# sourceMappingURL=ftp-client.ios.js.map