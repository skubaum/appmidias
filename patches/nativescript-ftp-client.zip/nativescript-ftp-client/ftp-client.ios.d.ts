export declare class FtpClient {
}
